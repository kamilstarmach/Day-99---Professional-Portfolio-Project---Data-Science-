import csv
import tempfile
import unittest
from pathlib import Path

from main import analyze_column, analyze_dataset, correlation, create_html_report, load_csv, parse_number


class PulseLabTests(unittest.TestCase):
    def test_parse_number_handles_blanks_and_commas(self):
        self.assertEqual(parse_number("1,250.5"), 1250.5)
        self.assertIsNone(parse_number(""))
        self.assertIsNone(parse_number("not a number"))
        self.assertIsNone(parse_number("nan"))

    def test_numeric_column_summary(self):
        result = analyze_column(["1", "2", "3", "4"])
        self.assertEqual(result["type"], "numeric")
        self.assertEqual(result["mean"], 2.5)
        self.assertEqual(result["median"], 2.5)
        self.assertEqual(result["min"], 1.0)
        self.assertEqual(result["max"], 4.0)

    def test_categorical_column_summary(self):
        result = analyze_column(["red", "blue", "red", ""])
        self.assertEqual(result["type"], "categorical")
        self.assertEqual(result["unique"], 2)
        self.assertEqual(result["missing"], 1)
        self.assertEqual(result["top_values"][0], {"value": "red", "count": 2})

    def test_correlation(self):
        self.assertEqual(correlation([1, 2, 3], [2, 4, 6]), 1.0)
        self.assertIsNone(correlation([1, 1, 1], [2, 3, 4]))

    def test_dataset_summary(self):
        rows = [
            {"units": "1", "revenue": "10", "region": "N"},
            {"units": "2", "revenue": "20", "region": "S"},
            {"units": "3", "revenue": "30", "region": "N"},
        ]
        report = analyze_dataset(rows)
        self.assertEqual(report["row_count"], 3)
        self.assertEqual(report["column_count"], 3)
        self.assertEqual(report["numeric_correlations"]["units__revenue"], 1.0)

    def test_empty_dataset_rejected(self):
        with self.assertRaises(ValueError):
            analyze_dataset([])

    def test_html_report_created_and_escapes_title(self):
        report = analyze_dataset([{"name": "<script>", "value": "2"}, {"name": "blue", "value": "4"}])
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "report.html"
            create_html_report(report, output, "<Test>")
            text = output.read_text(encoding="utf-8")
        self.assertIn("&lt;Test&gt;", text)
        self.assertNotIn("<title><Test></title>", text)


if __name__ == "__main__":
    unittest.main()
