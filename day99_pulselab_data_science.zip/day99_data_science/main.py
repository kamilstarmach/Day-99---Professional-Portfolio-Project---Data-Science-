"""PulseLab — an end-to-end exploratory data analysis toolkit."""
from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
import sys
from collections import Counter
from pathlib import Path
from typing import Any

NUMERIC_HINTS = {"age", "salary", "income", "price", "score", "rating", "quantity", "sales", "revenue", "hours", "weight", "height"}


def load_csv(path: Path) -> list[dict[str, str]]:
    """Read a CSV file into a list of dictionaries."""
    try:
        with path.open("r", newline="", encoding="utf-8-sig") as file:
            return list(csv.DictReader(file))
    except OSError as exc:
        raise ValueError(f"Could not read CSV file: {exc}") from exc


def parse_number(value: Any) -> float | None:
    """Convert a value to float; return None for blanks and non-numeric values."""
    if value is None:
        return None
    text = str(value).strip().replace(",", "")
    if not text:
        return None
    try:
        number = float(text)
        return number if math.isfinite(number) else None
    except ValueError:
        return None


def analyze_column(values: list[Any]) -> dict[str, Any]:
    """Summarize a column as numeric or categorical data."""
    numbers = [n for value in values if (n := parse_number(value)) is not None]
    nonempty = [str(value).strip() for value in values if value is not None and str(value).strip()]
    missing = len(values) - len(nonempty)
    if numbers and len(numbers) >= max(2, math.ceil(len(nonempty) * 0.7)):
        ordered = sorted(numbers)
        return {
            "type": "numeric",
            "count": len(numbers),
            "missing": missing,
            "mean": round(statistics.mean(numbers), 4),
            "median": round(statistics.median(numbers), 4),
            "min": round(min(numbers), 4),
            "max": round(max(numbers), 4),
            "stdev": round(statistics.stdev(numbers), 4) if len(numbers) > 1 else 0.0,
            "q1": round(ordered[(len(ordered) - 1) // 4], 4),
            "q3": round(ordered[(3 * (len(ordered) - 1)) // 4], 4),
        }
    counts = Counter(nonempty)
    return {
        "type": "categorical",
        "count": len(nonempty),
        "missing": missing,
        "unique": len(counts),
        "top_values": [{"value": value, "count": count} for value, count in counts.most_common(5)],
    }


def correlation(x: list[float], y: list[float]) -> float | None:
    """Pearson correlation for paired numeric values; None if undefined."""
    if len(x) != len(y) or len(x) < 2:
        return None
    mean_x, mean_y = statistics.mean(x), statistics.mean(y)
    numerator = sum((a - mean_x) * (b - mean_y) for a, b in zip(x, y))
    denom_x = sum((a - mean_x) ** 2 for a in x)
    denom_y = sum((b - mean_y) ** 2 for b in y)
    if denom_x == 0 or denom_y == 0:
        return None
    return round(numerator / math.sqrt(denom_x * denom_y), 4)


def analyze_dataset(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Generate dataset-level metadata, column summaries, and correlations."""
    if not rows:
        raise ValueError("The dataset is empty.")
    columns = list(rows[0].keys())
    summary = {column: analyze_column([row.get(column) for row in rows]) for column in columns}
    numeric_columns = [name for name, details in summary.items() if details["type"] == "numeric"]
    correlations = {}
    for i, left in enumerate(numeric_columns):
        for right in numeric_columns[i + 1:]:
            pairs = [
                (parse_number(row.get(left)), parse_number(row.get(right)))
                for row in rows
            ]
            paired = [(x, y) for x, y in pairs if x is not None and y is not None]
            value = correlation([p[0] for p in paired], [p[1] for p in paired])
            if value is not None:
                correlations[f"{left}__{right}"] = value
    return {
        "row_count": len(rows),
        "column_count": len(columns),
        "columns": summary,
        "numeric_correlations": correlations,
    }


def create_html_report(report: dict[str, Any], output: Path, title: str = "PulseLab Data Report") -> None:
    """Create a standalone HTML report with a compact summary and column table."""
    import html
    rows = []
    for name, item in report["columns"].items():
        if item["type"] == "numeric":
            detail = f"mean {item['mean']} · median {item['median']} · range {item['min']}–{item['max']}"
        else:
            top = ", ".join(f"{v['value']} ({v['count']})" for v in item["top_values"])
            detail = f"{item['unique']} unique · top: {top}"
        rows.append(
            "<tr><td>" + html.escape(str(name)) + "</td><td>" + item["type"] +
            "</td><td>" + str(item["count"]) + "</td><td>" + str(item["missing"]) +
            "</td><td>" + html.escape(detail) + "</td></tr>"
        )
    correlations = "".join(
        f"<li><code>{html.escape(key.replace('__', ' ↔ '))}</code>: {value}</li>"
        for key, value in report["numeric_correlations"].items()
    ) or "<li>No valid numeric correlations found.</li>"
    document = f"""<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title><style>
:root{{--bg:#101613;--panel:#19221c;--line:#2c3b30;--text:#edf4ec;--muted:#a2b2a5;--accent:#c7f36b}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--text);font:15px/1.6 system-ui,sans-serif}}
main{{max-width:1100px;margin:0 auto;padding:48px 24px}}.eyebrow{{color:var(--accent);letter-spacing:2px;font-size:11px;text-transform:uppercase}}
h1{{font-size:clamp(32px,6vw,56px);line-height:1.05;letter-spacing:-2px;margin:10px 0}}.muted{{color:var(--muted)}}
.cards{{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin:32px 0}}.card{{padding:20px;background:var(--panel);border:1px solid var(--line);border-radius:12px}}
.card strong{{font-size:30px;display:block}}.card span{{font-size:11px;letter-spacing:1px;color:var(--muted)}}
.table-wrap{{overflow-x:auto;border:1px solid var(--line);border-radius:12px}}table{{width:100%;border-collapse:collapse;min-width:650px}}th,td{{text-align:left;padding:13px 15px;border-bottom:1px solid var(--line)}}th{{font-size:11px;color:var(--accent);letter-spacing:1px;text-transform:uppercase}}td{{font-size:13px}}tr:last-child td{{border-bottom:0}}code{{color:var(--accent)}}section{{margin-top:34px}}@media(max-width:600px){{.cards{{grid-template-columns:1fr}}main{{padding:30px 16px}}}}
</style></head><body><main>
<p class="eyebrow">PulseLab / Exploratory data analysis</p><h1>{html.escape(title)}</h1>
<p class="muted">A reproducible overview of the uploaded CSV dataset.</p>
<div class="cards"><div class="card"><strong>{report['row_count']:,}</strong><span>ROWS</span></div>
<div class="card"><strong>{report['column_count']}</strong><span>COLUMNS</span></div>
<div class="card"><strong>{sum(1 for x in report['columns'].values() if x['type']=='numeric')}</strong><span>NUMERIC FIELDS</span></div></div>
<section><p class="eyebrow">Column profiles</p><div class="table-wrap"><table><thead><tr><th>Column</th><th>Type</th><th>Valid</th><th>Missing</th><th>Summary</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div></section>
<section><p class="eyebrow">Numeric relationships</p><ul>{correlations}</ul><p class="muted">Correlation describes linear association, not causation.</p></section>
</main></body></html>"""
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(document, encoding="utf-8")


def make_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="PulseLab — explore a CSV dataset and export a report.")
    parser.add_argument("csv_file", nargs="?", type=Path, help="Path to your CSV file")
    parser.add_argument("--out", type=Path, default=Path("reports"), help="Output directory (default: reports)")
    parser.add_argument("--title", default="PulseLab Data Report", help="Report title")
    parser.add_argument("--demo", action="store_true", help="Analyze the included sample dataset")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = make_parser().parse_args(argv)
    source = Path(__file__).parent / "data" / "sample_sales.csv" if args.demo else args.csv_file
    if source is None:
        print("Error: provide a CSV path or use --demo.", file=sys.stderr)
        return 2
    try:
        rows = load_csv(source)
        report = analyze_dataset(rows)
        args.out.mkdir(parents=True, exist_ok=True)
        json_path = args.out / "analysis.json"
        html_path = args.out / "report.html"
        json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
        create_html_report(report, html_path, args.title)
        print(f"Analyzed {report['row_count']} rows and {report['column_count']} columns.")
        print(f"JSON summary: {json_path}")
        print(f"HTML report:  {html_path}")
        print("\nColumn overview:")
        for name, details in report["columns"].items():
            if details["type"] == "numeric":
                print(f"  {name}: mean={details['mean']}, median={details['median']}, missing={details['missing']}")
            else:
                print(f"  {name}: {details['unique']} unique values, missing={details['missing']}")
        return 0
    except (ValueError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
