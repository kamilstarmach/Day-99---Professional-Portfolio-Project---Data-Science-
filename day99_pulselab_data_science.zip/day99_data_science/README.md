# Day 99 — PulseLab
**100 Days of Code | Professional Portfolio Project — Data Science**

PulseLab is a lightweight exploratory data analysis (EDA) tool for CSV datasets. It profiles columns, summarizes numeric and categorical fields, estimates pairwise Pearson correlations, and exports both machine-readable JSON and a standalone HTML report.

## Features
- Reads CSV files with UTF-8 and UTF-8 BOM support
- Detects numeric and categorical columns
- Reports missing values, mean, median, min/max, standard deviation, quartiles, and top categories
- Computes pairwise Pearson correlations using complete numeric pairs
- Exports `analysis.json` and a responsive `report.html`
- Includes a sample sales dataset for a reproducible demo
- Uses the Python standard library only

## Requirements
- Python 3.10+
- No third-party dependencies

## Run the demo

```bash
python main.py --demo
```

Reports are written to the `reports/` directory by default. Open `reports/report.html` in a browser.

## Analyze your own dataset

```bash
python main.py data/your_dataset.csv --out reports --title "Customer Analysis"
```

The input CSV should have a header row. Blank cells are counted as missing. Numeric parsing supports thousands separators such as `1,250.50`.

## Run tests

```bash
python -m unittest discover -s tests -v
```

## Project structure

```text
day99_data_science/
├── main.py
├── README.md
├── requirements.txt
├── .gitignore
├── data/
│   └── sample_sales.csv
└── tests/
    └── test_pulselab.py
```

## Interpretation notes
- Correlations range from -1 to +1 and capture linear association.
- Correlation does not imply causation.
- Quartiles use a simple order-statistic selection, suitable for a compact learning project rather than a formal statistical package.
- Numeric/categorical detection is heuristic; review the column profiles before drawing conclusions.

## Skills demonstrated
CSV processing, descriptive statistics, missing-data handling, Pearson correlation, HTML report generation, HTML escaping, CLI design, and unit testing.
